
export interface Listing{
    id: string,
    name: string,
    description: string,
    price: number,
    userId: string,
    views: number,
}

