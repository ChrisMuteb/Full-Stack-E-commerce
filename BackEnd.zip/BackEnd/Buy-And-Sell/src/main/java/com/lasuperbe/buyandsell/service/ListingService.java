package com.lasuperbe.buyandsell.service;

import com.lasuperbe.buyandsell.entity.Listing;
import com.lasuperbe.buyandsell.repository.ListingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ListingService {
    private ListingRepository listingRepository;
    @Autowired
    public ListingService(ListingRepository listingRepository) {
        this.listingRepository = listingRepository;
    }

    public List<Listing> getListings(){
        return listingRepository.findAll();
    }

    public Listing getListing(String id){
        Optional<Listing> result = listingRepository.findById(id);
        Listing theListing = null;

        if(result.isPresent())
            theListing = result.get();
        else
            throw new RuntimeException("Did not find Listing id - " + id);
        return theListing;
    }

    public Listing createNewListing(Listing listing){

        return listingRepository.save(listing);
    }

    public List<Listing> getUserListing(String userId){
        return listingRepository.findByUserId(userId);
    }

    public Listing updateListing(String id, String userId, Listing updatedListing){
        listingRepository.updateListing(id, userId, updatedListing.getName(), updatedListing.getDescription(), updatedListing.getPrice());
        return listingRepository.findById(id).orElse(null);
    }

    public void deleteListing(String id) {
        listingRepository.deleteById(id);
    }
}
