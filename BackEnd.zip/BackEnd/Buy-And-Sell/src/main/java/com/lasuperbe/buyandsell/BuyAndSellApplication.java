package com.lasuperbe.buyandsell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuyAndSellApplication {

    public static void main(String[] args) {
        SpringApplication.run(BuyAndSellApplication.class, args);
    }

}
