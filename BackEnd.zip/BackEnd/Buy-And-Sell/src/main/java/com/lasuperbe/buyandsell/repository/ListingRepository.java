package com.lasuperbe.buyandsell.repository;

import com.lasuperbe.buyandsell.entity.Listing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ListingRepository extends JpaRepository<Listing, String> {
    @Query(value = "SELECT * FROM listings l WHERE l.user_id=?1", nativeQuery = true)
    List<Listing> findByUserId(String userId);

    @Modifying
    @Query(value = "UPDATE listings SET name=:name, description=:description, price=:price WHERE id=:id AND user_id=:userId", nativeQuery = true)
    int updateListing(@Param("id") String id, @Param("userId") String userId, @Param("name") String name, @Param("description") String description, @Param("price") Double price);

}
