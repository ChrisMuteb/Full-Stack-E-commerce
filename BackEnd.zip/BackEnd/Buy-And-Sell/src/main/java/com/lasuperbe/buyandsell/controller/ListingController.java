package com.lasuperbe.buyandsell.controller;

import com.lasuperbe.buyandsell.entity.Listing;
import com.lasuperbe.buyandsell.service.ListingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class ListingController {
    private ListingService listingService;

    @Autowired
    public ListingController(ListingService listingService) {
        this.listingService = listingService;
    }

    @GetMapping("/listings")
    public ResponseEntity<List<Listing>> getListingsRoute(){
        return ResponseEntity.ok(listingService.getListings());
    }

    @GetMapping("/listings/{id}")
    public ResponseEntity<Listing> getListingRoute(@PathVariable String id){
           return ResponseEntity.ok(listingService.getListing(id));
    }

    @PostMapping("/listings")
    public ResponseEntity<Listing> createNewListingRoute(@RequestBody Listing listing){
        String id = UUID.randomUUID().toString();
        listing.setId(id);

        return ResponseEntity.ok(listingService.createNewListing(listing));
    }

    @PutMapping("/listings/{id}/add-view")
    public ResponseEntity<Listing> addViewToListingRoute(@PathVariable String id){
        Listing listing = listingService.getListing(id);
        listing.setViews(listing.getViews()+1);
        return ResponseEntity.ok(listingService.createNewListing(listing));
    }

    @GetMapping("/users/{userId}/listings")
    public ResponseEntity<List<Listing>> getUserListingsRoute(@PathVariable String userId){
        return ResponseEntity.ok(listingService.getUserListing(userId));
    }

    @PutMapping("/listings/{id}")
    public ResponseEntity<Listing> updateListingRoute(@PathVariable String id, @RequestBody Listing updatedListing){
        // Assuming userId is known
        String userId = "12345";

        Listing updated = listingService.updateListing(id, userId, updatedListing);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/listings/{id}")
    public ResponseEntity<String> deleteListingRoute(@PathVariable String id){
        listingService.deleteListing(id);
        return ResponseEntity.ok("Data deleted");
    }
}
