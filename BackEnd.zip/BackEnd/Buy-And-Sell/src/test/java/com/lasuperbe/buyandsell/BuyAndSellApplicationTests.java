package com.lasuperbe.buyandsell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuyAndSellApplicationTests {

    @Test
    void contextLoads() {
    }

}
